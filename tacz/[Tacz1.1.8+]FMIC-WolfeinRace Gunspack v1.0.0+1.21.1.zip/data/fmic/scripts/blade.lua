---@diagnostic disable: trailing-space
local M = {}

function M.calcSpread(api, num, spread)
    -- 初始化计数器
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            melee_count = 1
        }
    end
    -- 根据计数器返回弹道形状
    if (cache.melee_count == 1) then
        return{(num-10)/1.4, (10-num)/1.4}
    elseif (cache.melee_count == 2) then
        return{(num-10)/1.4, (num-10)/1.4}
    elseif (cache.melee_count == 3) then
        return{num-10, 0}
    end
end

function M.shoot(api)
    -- 初始化计数器
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            melee_count = 1
        }
    end
    -- 攻击
    if (api:getAimingProgress() <= 1) then
        api:shootOnce(false)
        if (cache.melee_count ~= 3) then
            cache.melee_count = cache.melee_count + 1
        else
            cache.melee_count = 1
        end
    end
    api:cacheScriptData(cache)
end

return M