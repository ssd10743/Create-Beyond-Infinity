#version 400 compatibility
#define WORLD_OVERWORLD
#define vsh
#include "/program/c20_motion_blur.vsh"
